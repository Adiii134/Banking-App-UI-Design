---
name: Nova Banking
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#44474c'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#75777d'
  outline-variant: '#c5c6cd'
  surface-tint: '#525f75'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#0e1c2f'
  on-primary-container: '#77849c'
  inverse-primary: '#bac7e1'
  secondary: '#006d34'
  on-secondary: '#ffffff'
  secondary-container: '#54fd8f'
  on-secondary-container: '#007237'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#001e2f'
  on-tertiary-container: '#008cc7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3fe'
  primary-fixed-dim: '#bac7e1'
  on-primary-fixed: '#0e1c2f'
  on-primary-fixed-variant: '#3a475c'
  secondary-fixed: '#62ff95'
  secondary-fixed-dim: '#2fe378'
  on-secondary-fixed: '#00210b'
  on-secondary-fixed-variant: '#005226'
  tertiary-fixed: '#c9e6ff'
  tertiary-fixed-dim: '#89ceff'
  on-tertiary-fixed: '#001e2f'
  on-tertiary-fixed-variant: '#004c6e'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-currency:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-numeric:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.01em
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The brand conveys absolute fiscal security, engineering precision, and modern financial clarity. Designed specifically for contemporary digital wealth management and mobile banking, the interface balances institutional gravitas with dynamic, forward-leaning momentum.

The design system adopts a **Modern Corporate & Precision Minimalist** style. It leverages high-density data legibility, refined micro-surfaces, purposeful contrast, and crisp emerald/cyan state accents. The visual character avoids unnecessary decorative skeuomorphism in favor of structural clarity, confident typographic weight, and soft atmospheric containment.

## Colors

The palette establishes an authoritative financial foundation with high-contrast functional accents:

- **Primary (`#0B192C` & `#1E3E62`):** Deep Navy anchors header surfaces, critical actions, high-emphasis text, and dark-mode brand accents.
- **Secondary (`#00D26A` & `#06D6A0`):** Crisp Emerald accents indicate positive cash inflows, completed verification, yield growth, and primary confirmation signals.
- **Tertiary (`#0EA5E9`):** Precision Cyan/Sky serves interactive state highlights, secondary transfers, informational metrics, and dynamic charting strokes.
- **Neutrals & Surfaces (`#FFFFFF`, `#F8FAFC`, `#F1F5F9`, `#E2E8F0`):** High-clarity layered backdrops. Base canvases use `#F8FAFC`, elevated card containers utilize pure `#FFFFFF`, and structural boundaries utilize `#E2E8F0`.
- **Destructive / Outflow (`#EF4444`):** Pure signal red reserved strictly for negative net flows, transaction deductions, overdraft alerts, and critical account barriers.

## Typography

The type scale prioritizes numerical legibility and structural hierarchy:

- **Monetary & Metric Values:** Use tabular figures (`font-variant-numeric: tabular-nums`) across all balance rows, ledger amounts, and rates to prevent horizontal shifting during live data refreshes.
- **Headings & Balances:** Set in `Plus Jakarta Sans` with tight negative tracking to deliver modern financial confidence.
- **Body & Structural Data:** Set in `Inter` for optimal legibility at micro-sizes (11px–14px) across receipt logs, timestamps, metadata keys, and legal notices.

## Layout & Spacing

The layout is optimized for single-handed mobile navigation (375x812 base viewport) using a 4-column fluid mobile grid:

- **Canvas Safe Area:** Top margin conforms to the iOS notch / dynamic island (44px/54px inset). Bottom interactions anchor above the home indicator (34px safe margin).
- **Horizontal Margins:** Fixed `1.25rem` (20px) outer edge margins ensure comfortable edge tap targets and prevent accidental bezel clipping.
- **Component Padding Scale:**
  - Card containers use `1rem` (16px) or `1.25rem` (20px) internal padding.
  - Micro-chips and compact badges use `0.25rem` (4px) vertical and `0.5rem` (8px) horizontal padding.
  - Interactive rows observe a strict minimum tap boundary of `48px` height.

## Elevation & Depth

Visual depth is achieved through subtle surface containment, low-contrast borders, and diffuse ambient shadows rather than stark elevation:

- **Level 0 (Canvas):** Baseline slate surface (`#F8FAFC`). No elevation.
- **Level 1 (Card & Module Surfaces):** Solid `#FFFFFF` fill with a `1px` structural boundary in `#E2E8F0` and an ambient shadow: `0 1px 3px rgba(11, 25, 44, 0.04), 0 4px 12px rgba(11, 25, 44, 0.03)`.
- **Level 2 (Active Cards & Floating Sheets):** Solid `#FFFFFF` or frosted acrylic backdrop (`rgba(255, 255, 255, 0.85)` with `16px` blur) bounded by `#CBD5E1`, with shadow: `0 8px 24px rgba(11, 25, 44, 0.08)`.
- **Level 3 (Modal Bottom Sheets & Modals):** High-diffusion elevation: `0 -8px 32px rgba(11, 25, 44, 0.12)` layered above a `rgba(11, 25, 44, 0.4)` scrim.

## Shapes

The design system applies controlled, modern geometry that feels approachable yet institutional:

- **Container Surfaces & Cards:** Standard `rounded-lg` (16px / `1rem`) corner radius for transaction containers, balance overview blocks, and interactive widgets.
- **Bottom Sheets:** `24px` upper corner radii (`rounded-t-2xl`) for slide-up transfer flows and context menus.
- **Pills & Buttons:** Fully circular / pill geometry (`9999px`) applied to primary call-to-actions, status chips, micro-indicators, and tab toggles.
- **Form Inputs:** `12px` (`0.75rem`) balanced corner radius ensuring cohesion with adjacent cards and actionable buttons.

## Components

### Buttons
- **Primary Action:** Solid Deep Navy (`#0B192C`) fill, pure white text, pill radius (`9999px`), 48px height, `Inter` 14px bold text. Pressed state drops opacity to `0.9` with subtle scale transform (`0.98`).
- **Success / Positive Action:** Solid Emerald (`#00D26A`) fill with `#0B192C` high-contrast text for critical transactional completions.
- **Secondary / Ghost:** `#FFFFFF` fill with `1px` `#E2E8F0` outline and `#1E3E62` text.

### Badges & Status Indicators
- **Inflow / Credit:** `#00D26A` at 12% opacity background, `#008A44` label text with an initial `+` prefix.
- **Outflow / Debit:** `#F1F5F9` background, `#64748B` label text with a `-` prefix.
- **Pending / In Review:** `#0EA5E9` at 12% opacity background, `#0284C7` label text.
- Form factor: Fully rounded pill, `20px` height, uppercase tracking `0.04em`, 11px font size.

### Cards & Financial Modules
- **Account Balance Card:** Optional primary theme variation featuring Deep Navy gradient fill (`linear-gradient(135deg, #0B192C 0%, #1E3E62 100%)`), high-contrast white metrics, and cyan secondary charts. Standard secondary cards utilize `#FFFFFF` surface fills with `1px` `#E2E8F0` borders.

### Transaction List Items
- Structured 64px fixed-height rows.
- Merchant/recipient avatar: 40px rounded square (`10px` radius) or circle with tinted category background (`#F1F5F9`).
- Primary line: Bold title (`Plus Jakarta Sans` 14px). Secondary line: Category and timestamp (`Inter` 12px, `#64748B`).
- Right-aligned tabular value with directional sign and status coloration.

### Form Inputs
- 48px height, solid white or `#F8FAFC` background, `1px` border in `#E2E8F0`.
- Focus state: `1.5px` border in `#0EA5E9` with subtle outer glow ring (`0 0 0 3px rgba(14, 165, 233, 0.15)`).
- Prefix currency glyphs (e.g., `$`, `€`) set in bold deep navy.